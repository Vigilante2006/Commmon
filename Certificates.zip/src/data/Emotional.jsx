export const Questions = [
  {
    text: `1. When you look into the mirror, you don’t see yourself, it looks like you are looking at a stranger.`,
    options: [
      { id: 0, text: `Never`, marks: 0, isCorrect: false },
      { id: 1, text: `Once`, marks: 5, isCorrect: true },
      { id: 2, text: `Sometimes`, marks: 8, isCorrect: true },
      { id: 3, text: `Mostly`, marks: 10, isCorrect: true },
    ],
  },
  {
    text: `2. You feel that you can turn off or detach from other’s emotions affecting you. `,
    options: [
      { id: 0, text: `Never`, marks: 10, isCorrect: true },
      { id: 1, text: `Once`, marks: 5, isCorrect: true },
      { id: 2, text: `Sometimes`, marks: 8, isCorrect: true },
      { id: 3, text: `Mostly`, marks: 0, isCorrect: false },
    ],
  },
  {
    text: `3. While traveling and when you look outside the window you have a feeling that you are living in a dream`,
    options: [
      { id: 0, text: `Never`, marks: 0, isCorrect: false },
      { id: 1, text: `Once`, marks: 5, isCorrect: true },
      { id: 2, text: `Sometimes`, marks: 8, isCorrect: true },
      { id: 3, text: `Mostly`, marks: 10, isCorrect: true },
    ],
  },
  {
    text: `4. Your surrounding feels detached or surreal, as if there's a veil between you and the outside world. `,
    options: [
      { id: 0, text: `Never`, marks: 0, isCorrect: false },
      { id: 1, text: `Once`, marks: 5, isCorrect: true },
      { id: 2, text: `Sometimes`, marks: 8, isCorrect: true },
      { id: 3, text: `Mostly`, marks: 10, isCorrect: true },
    ],
  },
  {
    text: `5. You feel that you are not the person in your memories- as if, “I had not been involved in them”.`,
    options: [
      { id: 0, text: `Never`, marks: 0, isCorrect: false },
      { id: 1, text: `Once`, marks: 5, isCorrect: true },
      { id: 2, text: `Sometimes`, marks: 8, isCorrect: true },
      { id: 3, text: `Mostly`, marks: 10, isCorrect: true },
    ],
  },
  {
    text: `6. When you move your physical body, you do not feel in charge of the movements, you feel it is "automatic"- as if you are a robot.`,
    options: [
      { id: 0, text: `Never`, marks: 0, isCorrect: false },
      { id: 1, text: `Once`, marks: 5, isCorrect: true },
      { id: 2, text: `Sometimes`, marks: 8, isCorrect: true },
      { id: 3, text: `Mostly`, marks: 10, isCorrect: true },
    ],
  },
  {
    text: `7. In some tough love situations, you allow letting someone go through a painful life experience without interference for the sake of its greater life lesson`,
    options: [
      { id: 0, text: `Never`, marks: 0, isCorrect: false },
      { id: 1, text: `Once`, marks: 5, isCorrect: true },
      { id: 2, text: `Sometimes`, marks: 8, isCorrect: true },
      { id: 3, text: `Mostly`, marks: 10, isCorrect: true },
    ],
  },
  {
    text: `8. Your thinking pattern is. `,
    options: [
      { id: 0, text: `Never`, marks: 0, isCorrect: false },
      { id: 1, text: `Once`, marks: 5, isCorrect: true },
      { id: 2, text: `Sometimes`, marks: 8, isCorrect: true },
      { id: 3, text: `Mostly`, marks: 10, isCorrect: true },
    ],
  },
]
