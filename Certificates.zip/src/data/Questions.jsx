export const Questions = [
  {
    text: `1. Do you like helping others (including strangers) even if you do not take credit?`,
    options: [
      { id: 0, text: `Yes`, isCorrect: true },
      { id: 1, text: `No`, isCorrect: false },
    ],
  },
  {
    text: `2. Can you listen to someone speak for a longtime without mental wandering?`,
    options: [
      { id: 0, text: `Yes`, isCorrect: true },
      { id: 1, text: `No`, isCorrect: false },
    ],
  },
  {
    text: `3. Do you like to advice others when they need it even if it makes you uncomfortable?`,
    options: [
      { id: 0, text: `Yes`, isCorrect: true },
      { id: 1, text: `No`, isCorrect: false },
    ],
  },
  {
    text: `4. Do you think you can easily read a person's mind just by looking at their `,
    options: [
      { id: 0, text: `Yes`, isCorrect: false },
      { id: 1, text: `No`, isCorrect: true },
    ],
  },
  {
    text: `5. Do you feel comfortable around psychologically unstable people? (Depression, anxiety, anger etc.)`,
    options: [
      { id: 0, text: `Yes`, isCorrect: true },
      { id: 1, text: `No`, isCorrect: false },
    ],
  },
  {
    text: `6. Can you keep an information shared 100% confidential?`,
    options: [
      { id: 0, text: `Yes`, isCorrect: true },
      { id: 1, text: `No`, isCorrect: false },
    ],
  },
  {
    text: `7. Do you think you can work with the same person over extended period? `,
    options: [
      { id: 0, text: `Yes`, isCorrect: true },
      { id: 1, text: `No`, isCorrect: false },
    ],
  },
  {
    text: `8. Have you experienced psychological crisis or breakdowns? `,
    options: [
      { id: 0, text: `Yes`, isCorrect: true },
      { id: 1, text: `No`, isCorrect: false },
    ],
  },
  {
    text: `9. Do you easily get frustrated when people can’t change problematic behaviour? `,
    options: [
      { id: 0, text: `Yes`, isCorrect: false },
      { id: 1, text: `No`, isCorrect: true },
    ],
  },
  {
    text: `10. Do you believe that a person has hope after a breakdown in life? (E.g., Debts, loss of job, loss of loved one, exam failure etc.) `,
    options: [
      { id: 0, text: `Yes`, isCorrect: true },
      { id: 1, text: `No`, isCorrect: false },
    ],
  },
]
