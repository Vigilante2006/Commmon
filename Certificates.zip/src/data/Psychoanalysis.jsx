export const Questions = [
  {
    text: `1. Which is your favourite colour? `,
    options: [
      { id: 0, text: `Black`, marks: 10, isCorrect: true },
      { id: 1, text: `White`, marks: 10, isCorrect: true },
      { id: 2, text: `Blue`, marks: 10, isCorrect: true },
      { id: 3, text: `Orange`, marks: 10, isCorrect: true },
      { id: 4, text: `None`, marks: 0, isCorrect: false },
    ],
  },
  {
    text: `2. What is your strength? `,
    options: [
      { id: 0, text: `Trustworthiness`, marks: 10, isCorrect: true },
      { id: 1, text: `Creativity`, marks: 10, isCorrect: true },
      { id: 2, text: `Dedication`, marks: 10, isCorrect: true },
      { id: 3, text: `Empathy`, marks: 10, isCorrect: true },
    ],
  },
  {
    text: `3. What makes you angry?`,
    options: [
      { id: 0, text: `Nothing`, marks: 0, isCorrect: false },
      { id: 1, text: `Lies`, marks: 5, isCorrect: true },
      { id: 2, text: `Bad manners`, marks: 10, isCorrect: true },
      { id: 3, text: `Messy people/places`, marks: 8, isCorrect: true },
    ],
  },
  {
    text: `4. What would you like to do on your day-off?`,
    options: [
      {
        id: 0,
        text: `Spend time with family/friends`,
        marks: 10,
        isCorrect: false,
      },
      { id: 1, text: `Explore new places`, marks: 10, isCorrect: true },
      { id: 2, text: `Work`, marks: 10, isCorrect: true },
      { id: 3, text: `Party`, marks: 10, isCorrect: true },
    ],
  },
  {
    text: `5. What are your thoughts about junk food? `,
    options: [
      { id: 0, text: `I don't eat junk`, marks: 5, isCorrect: false },
      { id: 1, text: `I like trying new things`, marks: 10, isCorrect: true },
      {
        id: 2,
        text: `I stick only to my favorites`,
        marks: 8,
        isCorrect: true,
      },
      { id: 3, text: `There are no preferences `, marks: 0, isCorrect: true },
    ],
  },
  {
    text: `6. What would you do with infinite money? `,
    options: [
      { id: 0, text: `Keep it`, marks: 0, isCorrect: false },
      { id: 1, text: `Start a new business`, marks: 10, isCorrect: true },
      { id: 2, text: `Donate`, marks: 10, isCorrect: true },
      { id: 3, text: `Go shopping `, marks: 10, isCorrect: true },
    ],
  },
  {
    text: `7. What do your friends say about you? `,
    options: [
      { id: 0, text: `Strong`, marks: 10, isCorrect: false },
      { id: 1, text: `Loyal`, marks: 10, isCorrect: true },
      { id: 2, text: `Smart`, marks: 10, isCorrect: true },
      { id: 3, text: `Funny`, marks: 10, isCorrect: true },
    ],
  },
  {
    text: `8. Do you like surprises? `,
    options: [
      { id: 0, text: `No, I don't`, marks: 0, isCorrect: false },
      { id: 1, text: `Only healthy ones`, marks: 10, isCorrect: true },
      { id: 2, text: `Sometimes`, marks: 5, isCorrect: true },
      { id: 3, text: `Yes, I love them`, marks: 8, isCorrect: true },
    ],
  },
  {
    text: `9. Which of the following turns you on? `,
    options: [
      { id: 0, text: `Confidence`, marks: 5, isCorrect: false },
      { id: 1, text: `Etiquettes`, marks: 0, isCorrect: true },
      { id: 2, text: `Forbidden love`, marks: 8, isCorrect: true },
      { id: 3, text: `Pain`, marks: 10, isCorrect: true },
    ],
  },
  {
    text: `10. When was the last time you did something thoughtful for others? `,
    options: [
      { id: 0, text: `Within past few days`, marks: 8, isCorrect: false },
      { id: 1, text: `Within past few weeks `, marks: 5, isCorrect: true },
      { id: 2, text: `Within past few hours `, marks: 10, isCorrect: true },
      { id: 3, text: `I can't remember `, marks: 0, isCorrect: true },
    ],
  },
]
