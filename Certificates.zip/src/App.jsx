import React from 'react'
// import Certificate from './components/Certificate'
import Loginform from './components/Loginform'

function App() {
  return (
    <div className="w-full h-[100vh] flex items-center">
      <Loginform />
      {/* <Certificate /> */}
    </div>
  )
}

export default App
