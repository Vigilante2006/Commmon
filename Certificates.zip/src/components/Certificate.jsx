import React from "react";
import logo from "../assets/logo.jpg";
import auto from "../assets/auto.jpg";
import html2canvas from "html2canvas";
import jsPDF from "jspdf";

const Certificate = (props) => {

    const date = new Date();

    let day = date.getDate();
    let month = date.getMonth() + 1;
    month = (month < 10) ? "0" + month : month
    let year = date.getFullYear();

    const total = props.staminaScore + props.emotionalScore + props.psychoanalysisScore;


    const exportPdf = () => {
        const doc = document.getElementById('certificatePage')
        html2canvas(doc, { logging: true, letterRendering: 1, useCORS: true }).then(canvas => {
            const pdf = new jsPDF('p', 'pt', 'a4');
            pdf.addImage(canvas, 'PNG', 0, 0, canvas.width / (2.2), canvas.height / 2)
            pdf.save('certificate.pdf')
        });

    }


    return (
        <div id="certificatePage" className="flex flex-col justify-center items-center">
            <div className="w-3/4 my-4 bg-white shadow-2xl border-double border-[8px] border-[#bc1e2d] rounded">
                <div className="flex justify-end">
                    <img src={logo} alt="/" />
                </div>
                <div className="text-center p-4">
                    <h1 className="text-4xl text-center font-bold text-[#bc1e2d]">Certificate of Competency</h1>
                </div>
                <div>
                    <p className="text-xl font-semibold text-center">This certificate is granted to</p>
                    <h2 className="text-3xl mt-5 text-center font-semibold">{props.useName}</h2>
                    <p className="text-xl text-center my-5 mx-[140px] ">In recognition of succesfully completing the assessment that establishes the competency required
                        to be able to attempt the 122 hours of the Emotional First Aid course. </p>

                    <div className="pl-4 flex flex-col items-start justify-start">
                        <h2 className="text-xl font-semibold">Total Competency Scores : <span className="text-[#bc1e2d]">{total}/230</span></h2>
                        <h2 className="text-md font-lightbold">Total Stamina : {props.staminaScore}/50</h2>
                        <h2 className="text-md font-lightbold">Total Conscious Emotional Detachment  : {props.emotionalScore}/80</h2>
                        <h2 className="text-md font-lightbold">Total Psychoanalysis Of Disposition   :{props.psychoanalysisScore}/80</h2>
                    </div>
                </div>
                <div className="flex justify-between items-center p-4">
                    <div>
                        <p className="text-sm font-bold">Date</p>
                        <p className="text-xs font-normal">{`${day}-${month}-${year}`}</p>
                    </div>
                    <div>
                        <img src={auto} alt="/" />
                    </div>
                </div>
            </div>
            <button onClick={exportPdf} className="flex mx-auto mt-6 text-[var(--secondary)] border-0 py-2 px-5 focus:outline-none bg-[transparent] rounded">Download</button>
        </div>
    );
};

export default Certificate;