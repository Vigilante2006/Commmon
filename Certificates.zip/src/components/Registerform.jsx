import React, { useState } from 'react'
import { Link } from 'react-router-dom';

function Registerform() {

    // registeration block
    const handleSubmit = async (e) => {
        e.preventDefault();
        const displayName = e.target[0].value;
        const email = e.target[1].value;
        const password = e.target[2].value;
        const file = e.target[3].files[0];

        
    };
    return (
        <div className=' flex flex-col justify-evenly items-center w-[300px] h-[450px] rounded-[20px] bg-[#00000021] border-l-[1px] border-l-[#ffffff73] border-t-[1px] border-t-[#ffffff73]  border-r-[2px] border-r-[#00000073] border-b-[2px] border-b-[#00000073]'>
            <form onSubmit={handleSubmit} id='register' className="flex flex-col justify-evenly items-center w-full h-[90%]  text-[#e5ab50]">
                <input type="text" placeholder='Username' className='p-2 pt-0 w-[90%] bg-transparent border-b-[1px] border-[#8885856b] focus:outline-none color-red-600' />
                <input type="email" placeholder='Email' className='p-2 pt-0 w-[90%] bg-transparent border-b-[1px] border-[#8885856b] focus:outline-none color-red-600' />
                <input type="password" placeholder='Password' className='p-2 pt-0 w-[90%] bg-transparent border-b-[1px] border-[#8885856b] focus:outline-none color-red-600' />
                <button type='submit' className='p-2 w-[40%] rounded-[20px] bg-gradient-to-b from-violet-600 to-violet-400 hover:to-violet-600 hover:from-violet-400 text-white font-bold mt-3'>Register</button>
                <h6 className='text-white'>Already have account <Link to={"/login"} className=' cursor-pointer text-[#e5ab50] hover:border-b-[1px] border-[#e5ab50]'>Login</Link></h6>
            </form>
        </div>
    )
}

export default Registerform