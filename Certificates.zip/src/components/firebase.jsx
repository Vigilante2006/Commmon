import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getStorage } from "firebase/storage";
// import { getFirestore } from "firebase/firestore";

const firebaseConfig = {
    apiKey: "AIzaSyAEvWP0sgZKjutoWXs26ktum-reSI-DJ8E",
    authDomain: "efaa-ad9b1.firebaseapp.com",
    projectId: "efaa-ad9b1",
    storageBucket: "efaa-ad9b1.appspot.com",
    messagingSenderId: "492684693510",
    appId: "1:492684693510:web:65a37919d6ec4aa87e3387"
};

// Initialize Firebase
export const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const storage = getStorage();
// export const db = getFirestore(app);
