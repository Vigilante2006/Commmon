import React, { useState } from 'react'
import Certificate from './Certificate'
import { Questions } from '../data/Psychoanalysis'
import Fail from './Fail'


function Psychoanalysis(props) {
    const [showResults, setShowResults] = useState(false)
    const [currentQuestion, setCurrentQuestion] = useState(0)
    const [score, setScore] = useState(0)
    const paraText = `First, some context. In a complex society such as ours, people are challenged to adapt to
a constant flow of change. Each of us is subject to cultural, ethnic, religious, economic,
and political expectations while also trying to preserve our individual sense of self. While
we navigate our way through daily living, we do our best to preserve the values, ideals,
and dreams that make us unique.
Yet, people are expected to adapt and change to the relentless pressure to conform to
the society.
Unfortunately, many modern approaches to psychotherapy advocate on behalf of the
prevailing society’s definition of health. That is, the goals of some therapies involve
helping the individual learn to accommodate his or her actions and ideas to those
deemed ‘normal’. A person ‘should’ be extroverted, socially motivated, objective, and
open to change. Admirable as these qualities might be, they are not for everybody.
In contrast, historically, psychoanalysis has advocated for the enhancement of human
diversity through the nurturing of a person’s self-development. Psychoanalysis focuses on
the diversity occurring in individuals. This approach is at the heart of psychoanalytic
questions for self-awareness.`
    // Helper Functions

    /* A possible answer was clicked */
    const optionClicked = (isCorrect, marks) => {
        // Increment the score
        if (isCorrect) {
            setScore(score + marks)
        }

        if (currentQuestion + 1 < Questions.length) {
            setCurrentQuestion(currentQuestion + 1)
        } else {
            setShowResults(true)
        }
    }

    return (
        <div className="App">
            {/* 2. Show results or show the question game  */}
            {showResults ? (
                /* 3. Final Results */
                <div>
                    {score >= 6 ? <Certificate staminaScore={props.staminaScore} useName={props.useName} emotionalScore={props.emotionalScore} psychoanalysisScore={score} /> : <Fail Para={paraText} />}
                </div>
            ) : (
                /* 4. Question Card  */
                <div className="question-card">
                    {/* Current Question  */}
                    <h1 className='question-text'>PART 3 -PSYCHOANALYSIS OF DISPOSITION COMPETENCY (100 Marks)</h1>
                    <h2 className='question-text'>
                        Question: {currentQuestion + 1} out of {Questions.length}
                    </h2>
                    <h3 className="question-text">{Questions[currentQuestion].text}</h3>

                    {/* List of possible answers  */}
                    <ul>
                        {Questions[currentQuestion].options.map((option) => {
                            return (
                                <li
                                    key={option.id}
                                    onClick={() => optionClicked(option.isCorrect, option.marks)}
                                >
                                    {option.text}
                                </li>
                            )
                        })}
                    </ul>
                </div>
            )}
        </div>
    )
}

export default Psychoanalysis
