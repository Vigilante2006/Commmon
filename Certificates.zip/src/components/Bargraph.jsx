
import React from "react";
import { Bar } from "react-chartjs-2";

const Bargraph = () => {
  const data = {
    labels: ["1st Quarter", "2nd Quarter", "3rd Quarter", "4th Quarter"],
    datasets: [
      {
        label: "Scorecard",
        backgroundColor: "rgba(255,99,132,0.2)",
        borderColor: "rgba(255,99,132,1)",
        borderWidth: 1,
        hoverBackgroundColor: "rgba(255,99,132,0.4)",
        hoverBorderColor: "rgba(255,99,132,1)",
        data: [65, 59, 80, 81],
      },
    ],
  };
  return (
    <div className="w-full flex flex-col items-center justify-center">
      <Bar
        data={data}
        width={1000}
        height={400}
        options={{
          maintainAspectRatio: false,
          legend: {
            display: false,
          },
        }}
      />
    </div>
  );
};

export default Bargraph;