import React, { useState } from 'react'
import { Questions } from '../data/Emotional'
import Fail from './Fail'
import Psychoanalysis from './Psychoanalysis'


function Emotional(props) {
    const [showResults, setShowResults] = useState(false)
    const [currentQuestion, setCurrentQuestion] = useState(0)
    const [score, setScore] = useState(0)
    const paraText = `Conscious Emotional Detachment and Depersonalization disorder are often confused by
people outside of the field of psychology. Depersonalization is a disorder in the sense that
there is an ‘inability to connect’, whereas Conscious Emotional Detachment is mental
assertiveness. It is a positive and deliberate mental attitude that avoids engaging with the
emotions of others.
This detachment does not mean avoiding the feeling of empathy; it is actually more of an
awareness of empathetic feelings that allows the person the space needed to rationally
choose whether or not to engage or be overwhelmed by such feelings.
`
    // Helper Functions

    /* A possible answer was clicked */
    const optionClicked = (isCorrect, marks) => {
        // Increment the score
        if (isCorrect) {
            setScore(score + marks)
        }

        if (currentQuestion + 1 < Questions.length) {
            setCurrentQuestion(currentQuestion + 1)
        } else {
            setShowResults(true)
        }
    }

    return (
        <div className="App">
            {/* 2. Show results or show the question game  */}
            {showResults ? (
                /* 3. Final Results */
                <div>
                    {score >= 30 ? <Psychoanalysis staminaScore={props.staminaScore} useName={props.useName} emotionalScore={score} /> : <Fail Para={paraText} />}
                </div>
            ) : (
                /* 4. Question Card  */
                <div className="question-card">
                    {/* Current Question  */}
                    <h1 className='question-text'>PART 2- CONSCIOUS EMOTIONAL DETACHMENT COMPENTENCY (80 marks)</h1>
                    <h2 className='question-text'>
                        Question: {currentQuestion + 1} out of {Questions.length}
                    </h2>
                    <h3 className="question-text">{Questions[currentQuestion].text}</h3>

                    {/* List of possible answers  */}
                    <ul>
                        {Questions[currentQuestion].options.map((option) => {
                            return (
                                <li
                                    key={option.id}
                                    onClick={() => optionClicked(option.isCorrect, option.marks)}
                                >
                                    {option.text}
                                </li>
                            )
                        })}
                    </ul>
                </div>
            )}
        </div>
    )
}

export default Emotional
