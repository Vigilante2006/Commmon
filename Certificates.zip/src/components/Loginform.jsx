import React, { useEffect, useState } from 'react'
import Stamina from './Stamina';
import logo from "../assets/logo.jpg";

const idb = window.indexedDB || window.mozIndexedDB || window.webkitIndexedDB || window.msIndexedDB || window.shimIndexedDB;

const handleSubmit = () => {

    // creating DataBase

    if (!idb) {
        console.log("This browser dosen't support IndexDB");
        return;
    }

    console.log(idb);

    const request = idb.open("test-db", 2);

    request.onerror = (event) => {

        console.log("Error", event); console.log("An error occured with IndexedDB");
    };

    request.onupgradeneeded = (event) => {
        const db = request.result;
        if (!db.objectStoreNames.contains('userData')) {
            db.createObjectStore('userData', {
                keyPath: 'id',
            });
        }

    }
    request.onsuccess = () => {
        console.log('Database Updated Successfuly')
    }

};
function Loginform() {

    // const [allUsers, setAllUsers] = useState([]);
    const [naam, setNaam] = useState('')
    const [mail, setMail] = useState('')
    const [mobile, setMobile] = useState('')
    const [flag, setFlag] = useState(false)

    useEffect(() => {
        handleSubmit();
    }, [])

    
    const handleDB = (e) => {
        const dbPromise = idb.open("test-db", 2);

        if (naam && mail && mobile) {
            dbPromise.onsuccess = () => {
                const db = dbPromise.result;
                const tnx = db.transaction('userData', 'readwrite')
                const userData = tnx.objectStore('userData');
                const users = userData.put({
                    id: 1,
                    naam,
                    mail,
                    mobile
                })
                users.onsuccess = () => {
                    tnx.oncomplete = () => {
                        db.close();
                    }
                }
                users.onerror = (e) => {
                    console.log(e);
                }
                console.log(userData)
                console.log(users)
            }
            setFlag(true)
        }
    }

    return (
        <div className="App flex items-center flex-col">
            {/* 1. Header  */}
            <h1 id='title'>COMPETENCY TEST FOR MENTAL HEALTH PROFESSIONALS</h1>

            {/* 2. Show results or show the question game  */}
            {flag ? (
                <div>
                    {/* <h1>{score}</h1> */}
                    {<Stamina useName={naam} />}
                </div>
            ) : (
                <form onSubmit={handleDB} className='mt-5 flex flex-col justify-evenly items-center 
                w-[300px] h-[450px] rounded-[5px] bg-gradient-to-t from-gray-100 to-white drop-shadow-xl border border-[#bc1e2d]'>
                    <img src={logo} alt="" className='mt-[2rem]' />
                    <div id='login' className="flex flex-col justify-center items-center w-full h-[90%]">
                        <div className='flex flex-col justify-evenly items-center relative w-full h-[100%] text-[var(--secondary)]'>
                            <input onChange={(e) => setNaam(e.target.value)}
                                value={naam} type="text" placeholder='Student Name' className='p-2 pt-0 w-[90%] bg-transparent 
                border-b-[1px] border-[#bc1e2d] text-xl text-center focus:outline-none color-red-600 text-[#bc1e2d] ' />
                            <input onChange={(e) => setMail(e.target.value)}
                                value={mail} type="email" placeholder='Gmail Id' className='p-2 pt-0 w-[90%] bg-transparent 
                border-b-[1px] border-[#bc1e2d] text-xl text-center focus:outline-none color-red-600 text-[#bc1e2d] ' />
                            <input onChange={(e) => setMobile(e.target.value)}
                                value={mobile} type="text" placeholder='Phone Number' className='p-2 pt-0 w-[90%] bg-transparent 
                border-b-[1px] border-[#bc1e2d] text-xl text-center focus:outline-none color-red-600 text-[#bc1e2d] ' />
                            <button className='p-2 w-[40%] rounded-[20px] bg-gradient-to-b from-[#bc1e2d] 
                to-[#bc1e2d] hover:to-gray-100 hover:from-gray-100 hover:border-[#bc1e2d] border hover:text-[#bc1e2d] text-white font-bold' type="submit"
                                onClick={handleDB}>Start</button>
                        </div>
                    </div>
                </form>
            )}
        </div>
    )
}

export default Loginform