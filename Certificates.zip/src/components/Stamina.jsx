import React, { useState } from 'react'
import { Questions } from '../data/Questions'
import Emotional from './Emotional'
import Fail from './Fail'


function Stamina(props) {
    const [showResults, setShowResults] = useState(false)
    const [currentQuestion, setCurrentQuestion] = useState(0)
    const [score, setScore] = useState(0)
    const paraText = `Mental Health Professionals face stress from a variety of sources. Deadlines, irregular
hours, mountains of paperwork, and clients dealing with major life crises are just a few of
the things that might put a drain on your emotions. Good stress management skills are
essential.
This does not mean that you need to feel discouraged if you struggle to deal with stress.
There are plenty of ways to build resilience, and you might actually find that helping other
people might make you feel calmer and more capable.
`
    // Helper Functions

    /* A possible answer was clicked */
    const optionClicked = (isCorrect) => {
        // Increment the score
        if (isCorrect) {
            setScore(score + 5)
        }

        if (currentQuestion + 1 < Questions.length) {
            setCurrentQuestion(currentQuestion + 1)
        } else {
            setShowResults(true)
        }
    }

    return (
        <div className="App">
            {showResults ? (
                /* 3. Final Results */
                <div>
                    {/* <h1>{score}</h1> */}
                    {score >= 30 ? <Emotional staminaScore={score} useName={props.useName} /> : <Fail Para={paraText} />}
                </div>
            ) : (
                /* 4. Question Card  */
                <div className="question-card">
                    {/* Current Question  */}
                    <h1 className='question-text'>PART 1- STAMINA COMPETENCY: (50Marks)</h1>
                    <h2 className='question-text'>
                        Question: {currentQuestion + 1} out of {Questions.length}
                    </h2>
                    <h3 className="question-text">{Questions[currentQuestion].text}</h3>

                    {/* List of possible answers  */}
                    <ul>
                        {Questions[currentQuestion].options.map((option) => {
                            return (
                                <li
                                    key={option.id}
                                    onClick={() => optionClicked(option.isCorrect)}
                                >
                                    {option.text}
                                </li>
                            )
                        })}
                    </ul>
                </div>
            )}
        </div>
    )
}

export default Stamina
